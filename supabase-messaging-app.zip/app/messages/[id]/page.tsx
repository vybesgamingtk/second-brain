import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { MessageThread } from "@/components/message-thread"
import { MessageInput } from "@/components/message-input"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default async function ConversationPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Verify user is part of this conversation
  const { data: participant } = await supabase
    .from("conversation_participants")
    .select("*")
    .eq("conversation_id", id)
    .eq("user_id", user.id)
    .single()

  if (!participant) {
    redirect("/messages")
  }

  // Get conversation participants
  const { data: participants } = await supabase
    .from("conversation_participants")
    .select(
      `
      user_id,
      profiles (
        id,
        display_name,
        avatar_url
      )
    `,
    )
    .eq("conversation_id", id)

  // Get other participant's name for header
  const otherParticipant = participants?.find((p) => p.user_id !== user.id)
  const conversationName = otherParticipant?.profiles?.display_name || "Unknown User"

  // Fetch messages
  const { data: messages } = await supabase
    .from("messages")
    .select(
      `
      id,
      content,
      created_at,
      sender_id,
      profiles:sender_id (
        id,
        display_name,
        avatar_url
      )
    `,
    )
    .eq("conversation_id", id)
    .order("created_at", { ascending: true })

  return (
    <div className="flex h-screen flex-col">
      <header className="border-b bg-background">
        <div className="flex h-16 items-center gap-4 px-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/messages">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary font-semibold">
              {conversationName.charAt(0).toUpperCase()}
            </div>
            <div>
              <h1 className="font-semibold">{conversationName}</h1>
            </div>
          </div>
        </div>
      </header>

      <MessageThread messages={messages || []} currentUserId={user.id} conversationId={id} />

      <div className="border-t bg-background p-4">
        <MessageInput conversationId={id} />
      </div>
    </div>
  )
}
