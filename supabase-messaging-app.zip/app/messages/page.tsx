import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { ConversationList } from "@/components/conversation-list"
import { NewConversationDialog } from "@/components/new-conversation-dialog"
import { Button } from "@/components/ui/button"
import { MessageSquare, Plus, Database } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default async function MessagesPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Fetch conversations with latest message and participant info
  const { data: conversations, error } = await supabase
    .from("conversation_participants")
    .select(
      `
      conversation_id,
      conversations (
        id,
        updated_at,
        conversation_participants (
          user_id,
          profiles (
            id,
            display_name,
            avatar_url
          )
        )
      )
    `,
    )
    .eq("user_id", user.id)
    .order("conversations(updated_at)", { ascending: false })

  if (error && error.code === "PGRST204") {
    return (
      <div className="flex h-screen flex-col">
        <header className="border-b bg-background">
          <div className="flex h-16 items-center justify-between px-4">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-semibold">Messages</h1>
            </div>
          </div>
        </header>

        <div className="flex-1 flex items-center justify-center p-4">
          <Alert className="max-w-2xl">
            <Database className="h-4 w-4" />
            <AlertTitle>Database Setup Required</AlertTitle>
            <AlertDescription className="space-y-2">
              <p>
                The messaging app database tables haven't been created yet. Please run the SQL scripts to set up your
                database:
              </p>
              <ol className="list-decimal list-inside space-y-1 text-sm">
                <li>Click the "Run Script" button for each SQL file in the scripts folder</li>
                <li>Run them in order: 001, 002, 003, 004</li>
                <li>Refresh this page after running all scripts</li>
              </ol>
            </AlertDescription>
          </Alert>
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-screen flex-col">
      <header className="border-b bg-background">
        <div className="flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <MessageSquare className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-semibold">Messages</h1>
          </div>
          <NewConversationDialog>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-2" />
              New Chat
            </Button>
          </NewConversationDialog>
        </div>
      </header>

      <div className="flex-1 overflow-hidden">
        {conversations && conversations.length > 0 ? (
          <ConversationList conversations={conversations} userId={user.id} />
        ) : (
          <div className="flex h-full items-center justify-center">
            <div className="text-center space-y-4">
              <div className="flex justify-center">
                <div className="rounded-full bg-muted p-6">
                  <MessageSquare className="h-12 w-12 text-muted-foreground" />
                </div>
              </div>
              <div className="space-y-2">
                <h2 className="text-xl font-semibold">No conversations yet</h2>
                <p className="text-sm text-muted-foreground">Start a new conversation to begin messaging</p>
              </div>
              <NewConversationDialog>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Start Conversation
                </Button>
              </NewConversationDialog>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
