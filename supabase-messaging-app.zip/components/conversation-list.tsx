"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import Link from "next/link"

type Conversation = {
  conversation_id: string
  conversations: {
    id: string
    updated_at: string
    conversation_participants: Array<{
      user_id: string
      profiles: {
        id: string
        display_name: string
        avatar_url: string | null
      } | null
    }>
  } | null
}

export function ConversationList({
  conversations: initialConversations,
  userId,
}: {
  conversations: Conversation[]
  userId: string
}) {
  const [conversations, setConversations] = useState(initialConversations)
  const supabase = createClient()

  useEffect(() => {
    setConversations(initialConversations)
  }, [initialConversations])

  useEffect(() => {
    const channel = supabase
      .channel("conversations")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "conversations",
        },
        async () => {
          // Refetch conversations when any conversation is updated
          const { data: updatedConversations } = await supabase
            .from("conversation_participants")
            .select(
              `
              conversation_id,
              conversations (
                id,
                updated_at,
                conversation_participants (
                  user_id,
                  profiles (
                    id,
                    display_name,
                    avatar_url
                  )
                )
              )
            `,
            )
            .eq("user_id", userId)
            .order("conversations(updated_at)", { ascending: false })

          if (updatedConversations) {
            setConversations(updatedConversations as Conversation[])
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [userId, supabase])

  return (
    <div className="h-full overflow-y-auto">
      <div className="divide-y">
        {conversations.map((conv) => {
          if (!conv.conversations) return null

          const otherParticipant = conv.conversations.conversation_participants.find((p) => p.user_id !== userId)

          const name = otherParticipant?.profiles?.display_name || "Unknown User"
          const initial = name.charAt(0).toUpperCase()

          return (
            <Link
              key={conv.conversation_id}
              href={`/messages/${conv.conversation_id}`}
              className="block hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center gap-3 p-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary font-semibold text-lg">
                  {initial}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold truncate">{name}</h3>
                  <p className="text-sm text-muted-foreground">
                    {new Date(conv.conversations.updated_at).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
