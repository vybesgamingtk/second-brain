"use client"

import { useEffect, useRef, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { cn } from "@/lib/utils"

type Message = {
  id: string
  content: string
  created_at: string
  sender_id: string
  profiles: {
    id: string
    display_name: string
    avatar_url: string | null
  } | null
}

export function MessageThread({
  messages: initialMessages,
  currentUserId,
  conversationId,
}: {
  messages: Message[]
  currentUserId: string
  conversationId: string
}) {
  const [messages, setMessages] = useState(initialMessages)
  const scrollRef = useRef<HTMLDivElement>(null)
  const supabase = createClient()

  useEffect(() => {
    setMessages(initialMessages)
  }, [initialMessages])

  useEffect(() => {
    const channel = supabase
      .channel(`conversation:${conversationId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `conversation_id=eq.${conversationId}`,
        },
        async (payload) => {
          // Fetch the complete message with profile data
          const { data: newMessage } = await supabase
            .from("messages")
            .select(
              `
              id,
              content,
              created_at,
              sender_id,
              profiles:sender_id (
                id,
                display_name,
                avatar_url
              )
            `,
            )
            .eq("id", payload.new.id)
            .single()

          if (newMessage) {
            setMessages((prev) => [...prev, newMessage as Message])
          }
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [conversationId, supabase])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  return (
    <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
      {messages.length === 0 ? (
        <div className="flex h-full items-center justify-center">
          <p className="text-sm text-muted-foreground">No messages yet. Start the conversation!</p>
        </div>
      ) : (
        messages.map((message) => {
          const isOwn = message.sender_id === currentUserId
          const senderName = message.profiles?.display_name || "Unknown"

          return (
            <div key={message.id} className={cn("flex gap-3", isOwn && "flex-row-reverse")}>
              <div
                className={cn(
                  "flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-semibold",
                  isOwn ? "bg-primary text-primary-foreground" : "bg-muted",
                )}
              >
                {senderName.charAt(0).toUpperCase()}
              </div>
              <div className={cn("flex flex-col gap-1", isOwn && "items-end")}>
                <div
                  className={cn(
                    "rounded-2xl px-4 py-2 max-w-md",
                    isOwn ? "bg-primary text-primary-foreground" : "bg-muted",
                  )}
                >
                  <p className="text-sm leading-relaxed">{message.content}</p>
                </div>
                <span className="text-xs text-muted-foreground px-2">
                  {new Date(message.created_at).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
            </div>
          )
        })
      )}
    </div>
  )
}
