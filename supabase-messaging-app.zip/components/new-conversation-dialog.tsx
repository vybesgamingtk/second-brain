"use client"

import type React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useRouter } from "next/navigation"

export function NewConversationDialog({
  children,
}: {
  children: React.ReactNode
}) {
  const [open, setOpen] = useState(false)
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  const handleCreateConversation = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const supabase = createClient()

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) return

      // Find user by email
      const { data: targetProfile } = await supabase.from("profiles").select("id").eq("id", email).single()

      if (!targetProfile) {
        // Try to find by looking up in auth metadata (this is a workaround)
        setError("User not found. Please check the email address.")
        setIsLoading(false)
        return
      }

      // Check if conversation already exists
      const { data: existingConversations } = await supabase
        .from("conversation_participants")
        .select("conversation_id")
        .eq("user_id", user.id)

      if (existingConversations) {
        for (const conv of existingConversations) {
          const { data: otherParticipant } = await supabase
            .from("conversation_participants")
            .select("user_id")
            .eq("conversation_id", conv.conversation_id)
            .eq("user_id", targetProfile.id)
            .single()

          if (otherParticipant) {
            // Conversation already exists
            router.push(`/messages/${conv.conversation_id}`)
            setOpen(false)
            return
          }
        }
      }

      // Create new conversation
      const { data: newConversation, error: convError } = await supabase
        .from("conversations")
        .insert({})
        .select()
        .single()

      if (convError) throw convError

      // Add both participants
      const { error: participantsError } = await supabase.from("conversation_participants").insert([
        { conversation_id: newConversation.id, user_id: user.id },
        { conversation_id: newConversation.id, user_id: targetProfile.id },
      ])

      if (participantsError) throw participantsError

      router.push(`/messages/${newConversation.id}`)
      setOpen(false)
      setEmail("")
    } catch (error) {
      console.error("Error creating conversation:", error)
      setError("Failed to create conversation. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Start a new conversation</DialogTitle>
          <DialogDescription>Enter the user ID of the person you want to message</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleCreateConversation} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">User ID</Label>
            <Input
              id="email"
              type="text"
              placeholder="Enter user ID"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <p className="text-xs text-muted-foreground">You can find user IDs in the profile section</p>
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Creating..." : "Start Chat"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
