-- Enable real-time for messages table
alter publication supabase_realtime add table messages;

-- Enable real-time for conversations table
alter publication supabase_realtime add table conversations;

-- Enable real-time for conversation_participants table
alter publication supabase_realtime add table conversation_participants;
